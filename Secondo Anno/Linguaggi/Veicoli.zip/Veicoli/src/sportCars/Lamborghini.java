package sportCars;

public class Lamborghini extends SportCar{
	public int nrGears;
	
	public Lamborghini(float motorizzazione, String carburante, int nrGears) {
		this.motorizzazione = motorizzazione;
		this.fuel = carburante;
		this.nrGears = nrGears;
	}
}
