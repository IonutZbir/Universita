package it.uniroma2.info.lmp;

public interface Professore extends Person {
	String getCattedra();
}
