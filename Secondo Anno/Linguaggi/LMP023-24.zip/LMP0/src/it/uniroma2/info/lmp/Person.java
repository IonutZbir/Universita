package it.uniroma2.info.lmp;

public interface Person {
	
	String getNome();

	String getCognome();

	void saluta();

}