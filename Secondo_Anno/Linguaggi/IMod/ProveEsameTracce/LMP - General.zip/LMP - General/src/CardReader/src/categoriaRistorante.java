public enum categoriaRistorante {

    //enumerazione delle categorie di ristorante ITALIANO, PIZZERIA, ETNICO
    ITALIANO, PIZZERIA, ETNICO;

}
