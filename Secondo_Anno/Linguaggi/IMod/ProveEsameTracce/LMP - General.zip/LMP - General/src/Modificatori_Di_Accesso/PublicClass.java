package Modificatori_Di_Accesso;

public class PublicClass {

    int number;

    public PublicClass() {

        this.number = 5;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
