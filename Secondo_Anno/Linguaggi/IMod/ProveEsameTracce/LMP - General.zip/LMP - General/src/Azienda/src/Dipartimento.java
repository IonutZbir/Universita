public enum Dipartimento {

    MARKETING,RISORSE_UMANE,SVILUPPO
}
