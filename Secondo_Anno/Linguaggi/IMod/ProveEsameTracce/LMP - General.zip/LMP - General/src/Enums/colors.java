package Enums;

public enum colors {
    ROSSO,
    VERDE,
    BLU,
    GIALLO,
}
