public class Ingrediente {

    public String nome;
    public double costoEttogrammo;
    public boolean pubblico;
    public int quantita;

    public Ingrediente(String nome, double costoEttogrammo, boolean pubblico, int quantita) {
        this.nome = nome;
        this.costoEttogrammo = costoEttogrammo;
        this.pubblico = pubblico;
        this.quantita = quantita;
    }

}
