public enum Portate {

    ANTIPASTI(1),
    PRIMI(2),
    SECONDI(3);

    public int numeroPortata;

    private Portate(int numeroPortata){
        this.numeroPortata = numeroPortata;
    }


}
