package Annotations;

public @interface Author {

    String author();
    String date();
    String version();

}
