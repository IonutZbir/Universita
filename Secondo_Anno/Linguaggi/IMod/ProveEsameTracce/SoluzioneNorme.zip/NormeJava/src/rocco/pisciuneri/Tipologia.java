package rocco.pisciuneri;

public enum Tipologia {
	leggeDelloStato, decreto, decretoLegge, decretolegislativo, ordinanza, provvedimento, circolare;
}
