package rocco.pisciuneri;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.awt.TextArea;
import java.util.HashMap;
import java.util.List;

public class Legge {
	private Tipologia tipo;
	private Date data;
	private List<Object> allegati;
	private String intestazione, conclusioni;
	private Map<Integer, Articolo> articoli;

	public Legge(Tipologia tipo, Date data, String intestazione, String conclusioni, Articolo... articolos) {
		this.tipo = tipo;
		this.data = data;
		this.intestazione = intestazione;
		this.conclusioni = conclusioni;
		allegati = new ArrayList<Object>();
		articoli = new HashMap<Integer, Articolo>();
		int i = 0;
		for (Articolo ar : articolos) {
			articoli.put(i++, ar);
		}
	}

	public Tipologia getTipo() {
		return tipo;
	}

	public Date getData() {
		return data;
	}

	public String getIntestazione() {
		return intestazione;
	}

	public List<Object> getAllegati() {
		return allegati;
	}

	public String getConclusioni() {
		return conclusioni;
	}

	public String toString() {
		return "Legge: " + getTipo() + ":" + getData().getYear() + "-" + getData().getMonth() + "-"
				+ getData().getDay();
	}

	public void aggiungiAllegato(Object allegato) {
		allegati.add(allegato);
	}

	public int getTuttiArticoli() {
		int i = 0;
		for (int c : articoli.keySet()) {
			i++;
		}
		return i;
	}
}
