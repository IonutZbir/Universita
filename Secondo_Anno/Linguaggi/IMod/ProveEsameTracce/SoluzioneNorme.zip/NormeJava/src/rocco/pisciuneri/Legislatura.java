package rocco.pisciuneri;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import rocco.pisciuneri.Legge;

public class Legislatura {
	private Map<Integer, Legge> leggi;

	public Legislatura() {
		leggi = new HashMap<Integer, Legge>();
	}

	public Legge cercaLegge(Tipologia tipo, Date data) {
		int leggeTrovata = 0;
		for (int l : leggi.keySet()) {
			if (leggi.get(l).getTipo() == tipo && leggi.get(l).getData() == data)
				leggeTrovata = l;
		}
		return leggi.get(leggeTrovata);
	}

	public void cercaLeggi(Tipologia tipo, Date data) {
		for (int l : leggi.keySet()) {
			if (leggi.get(l).getTipo() == tipo && leggi.get(l).getData().getYear() == data.getYear())
				System.out.println(leggi.get(l));
		}

	}

	public void articoliMaggioriDi20() {
		for (int l : leggi.keySet()) {
			if (leggi.get(l).getTuttiArticoli() >= 20)
				System.out.println(leggi.get(l));
		}

	}

}
