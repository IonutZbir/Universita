package rocco.pisciuneri;

import java.util.HashMap;
import java.util.Map;

public class Articolo {
	private int nArticolo;
	private String introduzione;
	private Map<Integer, String> commi;

	public Articolo(Legge leggeDiAppartenenza, int nArticolo, String introduzione) {
		this.nArticolo = nArticolo;
		this.introduzione = introduzione;
	}

	public Articolo(Legge leggeDiAppartenenza, int nArticolo, String introduzione, String... strings) {
		commi = new HashMap<Integer, String>();
		this.nArticolo = nArticolo;
		this.introduzione = introduzione;
		int i = 0;
		for (String comma : strings) {
			commi.put(i++, comma);
		}
	}

	public int getnArticolo() {
		return nArticolo;
	}

	public String getIntroduzione() {
		return introduzione;
	}

	public Map<Integer, String> getCommi() {
		return commi;
	}
	
	public int getTuttiCommi() {
		int i = 0;
		for (int c : commi.keySet()) {
			i++;
		}
		return i;
	}

}
